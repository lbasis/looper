package com.looper.core;

import android.util.SparseArray;

import com.looper.Logger;
import com.looper.interfaces.IMaterial;
import com.looper.interfaces.IPipe;
import com.looper.interfaces.IProcedure;
import com.looper.interfaces.IProcessResult;

import java.util.ArrayList;
import java.util.List;

public abstract class BasePipe<IM extends IMaterial<M>, M> implements IPipe<IM, M> {
    protected final String TAG = this.getClass().getSimpleName();
    private List<IProcedure> procedures = new ArrayList<>(2);
    /* key:index  value: error count*/
    private final SparseArray<Integer> completeResult = new SparseArray(8);
    protected int maxProcedure = 1;//最大工序
    protected boolean delete;

    /**
     * 单行管道：管道中只能存在一个原料在执行。
     *
     * @param procedure 工序数
     * @param delete    false:获取下一个元素元素执行的是next()，不移出列表；
     *                  true:获取下一个元素执行的是nextAndRemove()，会移出列表，此时没有机会判断IMaterial.available()
     */
    public BasePipe(int procedure, boolean delete) {
        if (procedure < 1) procedure = 1;
        maxProcedure = procedure;
        this.delete = delete;
        init();
    }

    private void init() {
        procedures.clear();
        Procedurer looper;
        for (int i = 0; i < maxProcedure; i++) {
            final int index = i;
            looper = new Procedurer<IM, M>("Procedure-" + i, delete) {
                long last = 0;

                @Override
                public boolean onProcess(IM material) {
                    //处理原料
                    IProcessResult<IM, M> result = BasePipe.this.onProcess(index, material);
                    material.setExecute(false);//非正在处理
                    // 处理成功移除列表
                    if (result.state()) {
                        remove(material);
                        removeCompleteResult(index + 1);
                    }
                    // TODO: 2021/5/11 输出信息
                    long dy = System.currentTimeMillis() - last;
                    if (dy < 200) {
                        Logger.e(TAG, getName() + " onProcess: dy = " + dy);
                    }
                    last = System.currentTimeMillis();
                    if (result.state()) {
                        Logger.e(TAG, getName() + "：" + material.material() + " 移出列表。");
                    } else {
                        if (material.available()) {
                            Logger.e(TAG, getName() + "：" + material.material() + " 等待再次尝试！");
                        } else {
                            Logger.e(TAG, getName() + "：" + material.material() + " 处理失败 ！！！！！！！！");
                        }
                    }
                    //控制管道流向
                    return onCustomControl(index, result);
                }

                @Override
                public void onComplete(int count) {
                    BasePipe.this.onComplete(index, count);
                }
            };
            procedures.add(looper);
        }
    }

    @Override
    public void apply(List<IM> os) {
        if (null == os || os.isEmpty()) return;
        IProcedure first = getProcedure(0);
        if (null == first) return;
        first.apply(os);
    }

    @Override
    public void apply(IM o) {
        if (null == o) return;
        IProcedure first = getProcedure(0);
        if (null == first) return;
        first.apply(o);
    }

    @Override
    public void pause() {
        for (int i = 0; i < maxProcedure; i++) {
            IProcedure looper = procedures.get(i);
            looper.pauseLoop();
        }
    }

    @Override
    public void resume() {
        for (int i = 0; i < maxProcedure; i++) {
            IProcedure looper = procedures.get(i);
            looper.resumeLoop();
        }
    }

    @Override
    public void clear() {
        for (int i = 0; i < maxProcedure; i++) {
            IProcedure looper = procedures.get(i);
            looper.clear();
        }
    }

    @Override
    public void release() {
        for (int i = 0; i < maxProcedure; i++) {
            IProcedure looper = procedures.get(i);
            looper.release();
        }
        procedures.clear();
    }

    @Override
    public IProcedure getProcedure(int index) {
        if (index > -1 && index < maxProcedure) {
            return procedures.get(index);
        }
        return null;
    }

    @Override
    public void onComplete(int index, int count) {
        completeResult.append(index, count);
        Logger.e(TAG, "onComplete: maxProcedure = " + maxProcedure + " size = " + completeResult.size());
        if (maxProcedure == completeResult.size()) {
            showResult();
        }
    }

    /**
     * apply 时 移出指定的result
     *
     * @param index
     */
    protected void removeCompleteResult(int index) {
        if (index > -1 && index < maxProcedure) {
            completeResult.remove(index);
        }
    }

    public void showResult() {
        StringBuilder builder = new StringBuilder();
        builder.append(" \n");
        int size = completeResult.size();
        for (int i = 0; i < size; i++) {
            int index = completeResult.keyAt(i);
            Integer count = completeResult.get(index);
            builder.append("onComplete: index = ");
            builder.append(index);
            builder.append("  error = ");
            builder.append(count);
            builder.append("\n");
        }
        Logger.e(TAG, builder.toString());
    }


    /**
     * 自定义控制管道流向
     *
     * @param index  索引
     * @param result 当前工序待处理的结果 待流转下道工序的原料
     * @return 当前工序轮训next标识 true：自定轮训next false：暂停轮训
     */
    @Override
    public abstract boolean onCustomControl(int index, IProcessResult<IM, M> result);

    /**
     * 处理原料，并封装成下一道工序的原料
     *
     * @param index    索引
     * @param material 当前工序待处理原料
     * @return 下一个工序的处理的原料
     */
    @Override
    public abstract IProcessResult<IM, M> onProcess(int index, IM material);
}
