package com.looper.core;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import androidx.annotation.NonNull;

import com.looper.Logger;
import com.looper.interfaces.IProcedure;
import com.looper.interfaces.IMaterial;

import java.lang.ref.WeakReference;

public class LpHandler extends Handler {
    private WeakReference<Procedurer> weakReference;
    private String loopName;

    public LpHandler(Procedurer procedurer) {
        loopName = procedurer.getName();
        weakReference = new WeakReference<>(procedurer);
    }

    @Override
    public void handleMessage(@NonNull Message msg) {
        Procedurer procedurer = weakReference.get();
        if (null != procedurer) {
            handleMessage(msg, procedurer);
        }
    }

    private long lastPre = 0;
//    private long lastAft = 0;

    private void handleMessage(@NonNull Message msg, Procedurer looper) {
        long dy = System.currentTimeMillis() - lastPre;
//        Logger.e("LpHandler", loopName + "****************************");
        Logger.e("LpHandler", loopName + " handleMessage 0 : dy = " + dy + (msg.what == IProcedure.CODE_APPLY ? " apply" : " next"));
        lastPre = System.currentTimeMillis();
        int what = msg.what;
        int surplus = looper.count();//此次添加时剩余量
        if (IProcedure.CODE_APPLY == what) {
            int count = looper.applyInLooper(msg.obj);
            showLog(surplus, count, looper.count());
            //添加后 立即轮训 delay = 0;
            looper.loop(0);
        } else if (IProcedure.CODE_NEXT == what || IProcedure.CODE_NEXT_AND_DELETE == what) {
            IMaterial m = looper.popInLooper(IProcedure.CODE_NEXT_AND_DELETE == what);
            if (null != m) {
                m.setExecute(true);//正在处理
                boolean next = looper.onProcess(m);
                m.setExecute(false);//非正在处理
                if (next) {
                    looper.loop(m.delay());
                }
            } else {
                looper.onComplete(surplus);
            }
        }
//        dy = System.currentTimeMillis() - lastAft;
//        Logger.e("LpHandler", loopName + " handleMessage 1 : dy = " + dy);
//        Logger.e("LpHandler", loopName + "****************************\n ");
//        lastAft = System.currentTimeMillis();
    }

    void showLog(int surplus, int apply, int total) {
        Logger.e("LpHandler", loopName
                + " : surplus = " + surplus
                + "  apply = " + apply
                + "  total = " + total);
    }
}
