package com.looper;

import com.looper.interfaces.IMaterial;
import com.looper.interfaces.IProcessResult;

public class ProcessResult<IM extends IMaterial<M>, M> implements IProcessResult<IM, M> {
    private boolean success;
    private IM imterial;

    public ProcessResult(IM result, boolean success) {
        this.imterial = result;
        this.success = success;
    }

    @Override
    public IM result() {
        return imterial;
    }

    @Override
    public boolean state() {
        return success;
    }
}
