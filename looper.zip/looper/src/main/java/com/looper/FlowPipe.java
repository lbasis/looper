package com.looper;

import com.looper.core.BasePipe;
import com.looper.interfaces.IMaterial;
import com.looper.interfaces.IProcedure;
import com.looper.interfaces.IProcessResult;

/**
 * 流管道：管道内可有若干个原料在做处理，最多存在原料数和管道的工序数一样。
 * 描述：向第一道工序分发原料，处理完成后,流转第二道工序，同时向第一道工序分发下一个原料；如此往复。
 * 注意： 前一道工序不需等待后面原料处理完成，本工序处理完成后 即开始处理下一个可用原料（若果还有待处理原料）
 */
public abstract class FlowPipe<IM extends IMaterial<M>, M> extends BasePipe<IM, M> {

    public FlowPipe(int looperSize, boolean once) {
        super(looperSize, once);
    }

    /**
     * 自定义控制管道流向
     *
     * @param index  索引
     * @param result 当前工序待处理的结果 待流转下道工序的原料
     * @return 当前工序轮训next标识 true：自定轮训next false：暂停轮训
     */
    public final boolean onCustomControl(int index, IProcessResult<IM,M> result) {
        //流转向下道工序
        IProcedure next = getProcedure(index + 1);
        if (null != result && null != next && result.state()) {
            next.apply(result.result());
        }
        return true;//当前工序loop next
    }
}
