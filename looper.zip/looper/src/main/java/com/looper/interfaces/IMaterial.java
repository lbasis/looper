package com.looper.interfaces;

public interface IMaterial<M> {
    /**
     * 原料
     */
    M material();

    /**
     * 处理延迟时间
     */
    long delay();

    /**
     * 原料是否可用
     */
    boolean available();

    /**
     * 设置正在处理标识
     * @param execute 正在处理标识
     */
    void setExecute(boolean execute);
}
