package com.looper.interfaces;

public interface IProcessResult<IM extends IMaterial<M>, M> {

    /**
     * 处理结果
     */
    IM result();

    /**
     * 处理是成功标识
     */
    boolean state();
}