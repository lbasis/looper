package com.looper;

import com.looper.core.BasePipe;
import com.looper.interfaces.IMaterial;
import com.looper.interfaces.IProcedure;
import com.looper.interfaces.IProcessResult;

/**
 * 单行管道：管道中只能存在一个原料被处理。
 * 描述：向第一道工序分发原料，处理后流向下道工序，直至最后一道工序完成，才开始向第一道工序分发下一个原料，如此往复。
 * 注意：第一道工序需要等待最后一道工序执行完毕后才能分发下一个原料
 */
public abstract class SinglePipe<IM extends IMaterial<M>, M> extends BasePipe<IM, M> {

    public SinglePipe(int looperSize, boolean once) {
        super(looperSize, once);
    }

    /**
     * 自定义控制管道流向:当前工序暂停轮训下一个，直至最后一道工序执行完毕
     *
     * @param index  索引
     * @param result 当前工序待处理的结果 待流转下道工序的原料
     * @return 当前工序轮训next标识 true：自定轮训next false：暂停轮训
     */
    @Override
    public final boolean onCustomControl(int index, IProcessResult<IM,M> result) {
        //流转向下道工序
        IProcedure next = getProcedure(index + 1);
        if (null != result && null != next && result.state()) {
            next.apply(result.result());
        }
        //直至最后一道工序处理完毕 才向管道（第一到工序）分发下个原料
        if (index == maxProcedure - 1) {
            getProcedure(0).loop(0);
        }
        // 当前工序停止轮训next 等待
        return false;
    }
}
