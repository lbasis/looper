package com.looper.interfaces;

import java.util.List;

/**
 * 工序接口
 *
 * @param <M>
 */
public interface IProcedure<M> {
    int CODE_APPLY = 70001;
    int CODE_NEXT = 70002;
    int CODE_NEXT_AND_DELETE = 70003;

    /**
     * 添加任务原料
     *
     * @param material 原料
     */
    void apply(IMaterial<M> material);

    /**
     * 批量添加
     *
     * @param materials
     */
    void apply(List<IMaterial<M>> materials);

    /**
     * 获取最早添加的可用原料 不移出
     */
    IMaterial<M> next();

    /**
     * 手动从原料队列中移出
     *
     * @param material
     */
    boolean remove(IMaterial<M> material);

    /**
     * 获取最早添加的可用原料 并从队列中移出
     * 相当与依次执行 next() 和 remove()
     */
    IMaterial<M> nextAndRemove();

    /**
     * 清空原料列表
     */
    void clear();

    /**
     * 轮训下一个原料
     *
     * @param delay
     */
    void loop(long delay);

    /**
     * 轮循原料
     *
     * @param delete 轮循原料是否从队列中删除
     * @param delay  延迟时间
     */
    void loop(boolean delete, long delay);

    /**
     * 当前原料记录数
     */
    int count();

    /**
     * 暂停 单不会影响正在处理的原料处理
     */
    void pauseLoop();

    /**
     * 恢复
     */
    void resumeLoop();

    /**
     * 释放资源 结束loop线程
     */
    void release();

    /**
     * 处理任务回调
     *
     * @param material
     * @return 是否自动流转的标识 true：流转  false：不流转
     */
    boolean onProcess(IMaterial<M> material);

    /**
     * 处理完毕回调
     *
     * @param count 处理失败的记录数
     */
    void onComplete(int count);
}
