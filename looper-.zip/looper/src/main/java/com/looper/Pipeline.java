package com.looper;

import android.os.SystemClock;

import com.looper.core.FlowPipe;
import com.looper.core.SinglePipe;
import com.looper.interfaces.IMaterial;
import com.looper.interfaces.IPipe;

import java.util.Random;

/**
 * 并行队列
 */
public class Pipeline extends FlowPipe {
    private final static Pipeline _queue = new Pipeline();

    public static IPipe getQueue() {
        return _queue;
    }

    private Pipeline() {
        super(2, false);
    }

    @Override
    public IMaterial onProcess(int index, IMaterial iMaterial) {
        // TODO: 2/24/21 模拟耗时操作
//        SystemClock.sleep(index == 0 ? 200 : 500);
        Material m = (Material) iMaterial;
        String result = m.material() + "_pro" + index;
        Logger.e(TAG, "index = " + index + " result = " + result);
        m.setCount(m.getCount() + 1);
        //随机模拟处理失败
        Random random = new Random();
        int count = random.nextInt();
        if (count > 0) {
            // TODO: 2/25/21 模拟处理成功后
            getProcedure(index).remove(m);
            Logger.e(TAG, "index = " + index + " 成功 移除");
        } else {
            // TODO: 2/25/21 模拟处理失败
            Logger.e(TAG, "index = " + index + " 处理失败！");
        }
        return new Material(result, 2);
    }
}
