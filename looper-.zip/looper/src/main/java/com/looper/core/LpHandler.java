package com.looper.core;

import android.os.Handler;
import android.os.Message;

import androidx.annotation.NonNull;

import com.looper.Logger;
import com.looper.interfaces.IProcedure;
import com.looper.interfaces.IMaterial;

import java.lang.ref.WeakReference;

public class LpHandler extends Handler {
    private WeakReference<Procedurer> weakReference;
    private String loopName;

    public LpHandler(Procedurer procedurer) {
        loopName = procedurer.getName();
        weakReference = new WeakReference<>(procedurer);
    }

    @Override
    public void handleMessage(@NonNull Message msg) {
        Procedurer procedurer = weakReference.get();
        if (null != procedurer) {
            handleMessage(msg, procedurer);
        }
    }

    private void handleMessage(@NonNull Message msg, Procedurer looper) {
        int what = msg.what;
        int surplus = looper.count();//此次添加时剩余量
        if (IProcedure.CODE_APPLY == what) {
            int count = looper.applyInLooper(msg.obj);
            showLog(surplus,count,looper.count());
            //添加后 立即轮训 delay = 0;
            looper.loop(0);
        } else if (IProcedure.CODE_NEXT == what || IProcedure.CODE_NEXT_AND_DELETE == what) {
            IMaterial m = looper.popInLooper(IProcedure.CODE_NEXT_AND_DELETE == what);
            if (null != m) {
                boolean next = looper.onProcess(m);
                if (next) {
                    looper.loop(m.delay());
                }
            } else {
                looper.onComplete(surplus);
            }
        }
    }

    void showLog(int surplus, int apply, int total) {
        Logger.e("LpHandler", loopName
                + " : 添加前剩余：" + surplus
                + " apply：" + apply
                + " total = " + total);
    }
}
