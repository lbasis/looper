package com.looper.core;

import com.looper.interfaces.IMaterial;

/**
 * 单行管道：管道中只能存在一个原料被处理。
 * 描述：向第一道工序分发原料，处理后流向下道工序，直至最后一道工序完成，才开始向第一道工序分发下一个原料，如此往复。
 * 注意：第一道工序需要等待最后一道工序执行完毕后才能分发下一个原料
 */
public abstract class SinglePipe extends FlowPipe {

    public SinglePipe(int looperSize, boolean once) {
        super(looperSize, once);
    }

    @Override
    public boolean handleProcess(int index, IMaterial material) {
        super.handleProcess(index, material);
        if (index == maxProcedure - 1) {//开始处理下一个原料
            getProcedure(0).loop(0);
        }
        return false;
    }
}
