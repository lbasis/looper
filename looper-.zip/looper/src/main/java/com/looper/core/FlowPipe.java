package com.looper.core;

import com.looper.Logger;
import com.looper.interfaces.IProcedure;
import com.looper.interfaces.IMaterial;
import com.looper.interfaces.IPipe;

import java.util.ArrayList;
import java.util.List;

/**
 * 流管道：管道内可有若干个原料在做处理，最多存在原料数和管道的工序数一样。
 * 描述：向第一道工序分发原料，处理完成后,流转第二道工序，同时向第一道工序分发下一个原料；如此往复。
 * 注意： 前一道工序不需等待后面原料处理完成，本工序处理完成后 即开始处理下一个可用原料（若果还有待处理原料）
 */
public abstract class FlowPipe implements IPipe {
    protected final String TAG = this.getClass().getSimpleName();
    private List<IProcedure> loopers = new ArrayList<>(2);
    protected int maxProcedure = 1;//最大工序
    protected boolean delete;

    /**
     * 单行管道：管道中只能存在一个原料在执行。
     *
     * @param procedure 工序数
     * @param delete    false:获取下一个元素元素执行的是next()，不移出列表；
     *                  true:获取下一个元素执行的是nextAndRemove()，会移出列表，此时没有机会判断IMaterial.available()
     */
    public FlowPipe(int procedure, boolean delete) {
        if (procedure < 1) procedure = 1;
        maxProcedure = procedure;
        this.delete = delete;
        init();
    }

    private void init() {
        loopers.clear();
        Procedurer looper;
        for (int i = 0; i < maxProcedure; i++) {
            final int index = i;
            looper = new Procedurer(TAG + "-Procedure-" + i, delete) {
                @Override
                public boolean onProcess(IMaterial material) {
                    return handleProcess(index, material);
                }

                @Override
                public void onComplete(int count) {
                    FlowPipe.this.onComplete(index, count);
                }
            };
            loopers.add(looper);
        }
    }

    @Override
    public void apply(List<IMaterial> os) {
        if (null == os || os.isEmpty()) return;
        IProcedure first = getProcedure(0);
        if (null == first) return;
        first.apply(os);
    }

    @Override
    public void apply(IMaterial o) {
        if (null == o) return;
        IProcedure first = getProcedure(0);
        if (null == first) return;
        first.apply(o);
    }

    @Override
    public void pause() {
        for (int i = 0; i < maxProcedure; i++) {
            IProcedure looper = loopers.get(i);
            looper.pauseLoop();
        }
    }

    @Override
    public void resume() {
        for (int i = 0; i < maxProcedure; i++) {
            IProcedure looper = loopers.get(i);
            looper.resumeLoop();
        }
    }

    @Override
    public void clear() {
        for (int i = 0; i < maxProcedure; i++) {
            IProcedure looper = loopers.get(i);
            looper.clear();
        }
    }

    @Override
    public void release() {
        for (int i = 0; i < maxProcedure; i++) {
            IProcedure looper = loopers.get(i);
            looper.release();
        }
        loopers.clear();
    }

    @Override
    public IProcedure getProcedure(int index) {
        if (index > -1 && index < maxProcedure) {
            return loopers.get(index);
        }
        return null;
    }

    /**
     * 处理当前任务 并分发下个工序
     *
     * @param index
     * @param material
     */
    protected boolean handleProcess(int index, IMaterial material) {
        IMaterial result = onProcess(index, material);
        IProcedure next = getProcedure(index + 1);
        if (null != result && null != next) {
            next.apply(result);//分发至下一工序
        }
        return true;//当前工序loop next
    }


    @Override
    public void onComplete(int index, int count) {
        Logger.e(TAG, "onComplete: index = " + index + " count = " + count);
    }

    @Override
    public abstract IMaterial onProcess(int index, IMaterial material);
}
