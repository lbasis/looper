package com.looper.core;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.text.TextUtils;

import com.looper.interfaces.IProcedure;
import com.looper.interfaces.IMaterial;

import java.util.ArrayList;
import java.util.List;

/**
 * 当个流程工序处理队列
 *
 * @param <M> 原料的类型
 */
public abstract class Procedurer<M> extends HandlerThread implements IProcedure<M> {
    private final static String TAG = "Procedurer";
    protected final List<IMaterial<M>> _materials = new ArrayList<>();
    private Handler loopHander;
    private boolean _pause;//是否暂停
    /**
     * 执行next时是否删除
     * 1. delete = false 获取下一个元素元素执行的是next()，不移出列表
     * 2. delete = true 获取下一个元素执行的是nextAndRemove()，会移出列表，此时没有机会判断IMaterial.available()
     */
    private boolean _delete;

    /**
     * @param name   名称
     * @param delete false:获取下一个元素元素执行的是next()，不移出列表；
     *               true:获取下一个元素执行的是nextAndRemove()，会移出列表，此时没有机会判断IMaterial.available()
     */
    public Procedurer(String name, boolean delete) {
        super(TextUtils.isEmpty(name) ? TAG : name);
        this._delete = delete;
        start();
        loopHander = new LpHandler(this);
    }

    @Override
    public int count() {
        synchronized (_materials) {
            return _materials.size();
        }
    }

    @Override
    public void apply(IMaterial<M> material) {
        //暂停next loop
//        loopHander.removeMessages(CODE_NEXT);
//        loopHander.removeMessages(CODE_NEXT_AND_DELETE);
        Message msg = Message.obtain();
        msg.what = CODE_APPLY;
        msg.obj = material;
        loopHander.sendMessage(msg);
    }

    @Override
    public void apply(List<IMaterial<M>> os) {
        //暂停next loop
//        loopHander.removeMessages(CODE_NEXT);
//        loopHander.removeMessages(CODE_NEXT_AND_DELETE);
        Message msg = Message.obtain();
        msg.what = CODE_APPLY;
        msg.obj = os;
        loopHander.sendMessage(msg);
    }

    @Override
    public IMaterial<M> next() {
        return popInLooper(false);
    }

    @Override
    public boolean remove(IMaterial<M> material) {
        synchronized (_materials) {
            return _materials.remove(material);
        }
    }

    @Override
    public IMaterial<M> nextAndRemove() {
        return popInLooper(true);
    }

    @Override
    public void clear() {
        synchronized (_materials) {
            _materials.clear();
        }
    }

    @Override
    public void loop(long delay) {
        loop(_delete, delay);
    }

    /**
     * 轮训下一个 不影响添加操作
     *
     * @param delete pop原料后是否删除
     * @param delay  延迟时间
     */
    @Override
    public void loop(boolean delete, long delay) {
        if (delay < 0) delay = 0;
        loopHander.removeMessages(CODE_NEXT);
        loopHander.removeMessages(CODE_NEXT_AND_DELETE);
        if (_pause) {
            return;
        }
        Message msg = Message.obtain();
        msg.what = delete ? CODE_NEXT_AND_DELETE : CODE_NEXT;
        loopHander.sendMessageDelayed(msg, delay);
    }

    public void resumeLoop() {
        _pause = false;
        loop(0);
    }

    @Override
    public void pauseLoop() {
        _pause = true;
    }

    @Override
    public void release() {
        clear();
        loopHander.removeMessages(CODE_APPLY);
        loopHander.removeMessages(CODE_NEXT);
        loopHander.removeMessages(CODE_NEXT_AND_DELETE);
        loopHander = null;
        quitSafely();
    }

    /**
     * 当前轮训线程处理 添加原料
     *
     * @param o
     */
    protected int applyInLooper(Object o) {
        if (o instanceof IMaterial) {//单个
            IMaterial m = (IMaterial) o;
            synchronized (_materials) {
                if (!_materials.contains(m)) {
                    _materials.add(m);
                }
            }
            return 1;
        } else if (o instanceof List) {// 批量
            List<IMaterial> ms = (List<IMaterial>) o;
            int len = null == ms ? 0 : ms.size();
            if (len < 1) return -1;
            int count = 0;
            synchronized (_materials) {
                for (int i = 0; i < len; i++) {
                    IMaterial m = ms.get(i);
                    if (!_materials.contains(m)) {
                        _materials.add(m);
                        count++;
                    }
                }
            }
            return count;
        }
        return -1;
    }

    /**
     * 当前轮训线程处理弹出一个可以的最早添加原料
     *
     * @param delete 弹出后是否重队列中移除 true：移除：false：不移除
     */
    protected IMaterial popInLooper(boolean delete) {
        IMaterial material = null;
        synchronized (_materials) {
            int len = _materials.size();
            for (int i = 0; i < len; i++) {
                IMaterial m = _materials.get(i);
                if (m.available()) {
                    material = m;
                    break;
                }
            }
            if (delete && null != material) {
                _materials.remove(material);
            }
        }
        return material;
    }


    @Override
    public void onComplete(int count) {
    }

    @Override
    public abstract boolean onProcess(IMaterial<M> material);

}
